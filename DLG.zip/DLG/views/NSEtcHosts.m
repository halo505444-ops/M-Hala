//
//  NSEtcHosts.m
//  JnDlg
//
//  Created by apple on 2019/4/28.
//

#import <Foundation/Foundation.h>

#import "EtcHostsURLProtocol.h"
@interface NSObject(hook)



@end


@implementation NSObject(hook)

+(void) load{
    
    [NSURLProtocol registerClass:[EtcHostsURLProtocol class]];
    [EtcHostsURLProtocol configureHostsWithBlock:^(id <EtcHostsConfiguration> configuration) {
        
        NSDictionary *dns = @{
                              @"dlied1.tcdn.qq.com":@"127.0.0.1",
                             
@"down.anticheatexpert.com":@"127.0.0.1",
@"qos.hk.gcloud.com":@"127.0.0.1",
@"qos.hk.gcloud.qq.com":@"127.0.0.1",
@"qos.hk.gcloudcs.com":@"127.0.0.1",
@"qos.hk.gcloudcs.qq.com":@"127.0.0.1",
@"qos.gcloud.com":@"127.0.0.1",
@"qos.gcloud.qq.com":@"127.0.0.1",
@"qos.gcloudcs.com":@"127.0.0.1",
@"qos.gcloudcs.qq.com":@"127.0.0.1",
@"capi.voice.gcloud.com":@"127.0.0.1",
@"capi.voice.gcloud.qq.com":@"127.0.0.1",
@"capi.voice.gcloudcs.com":@"127.0.0.1",
@"capi.voice.gcloudcs.qq.com":@"127.0.0.1",
@"qosidc.gcloud.com":@"127.0.0.1",
@"qosidc.gcloud.qq.com":@"127.0.0.1",
@"qosidc.gcloudcs.com":@"127.0.0.1",
@"qosidc.gcloudcs.qq.com":@"127.0.0.1",
@"cdn.cn.gcloud.com":@"127.0.0.1",
@"cdn.cn.gcloud.qq.com":@"127.0.0.1",
@"cdn.cn.gcloudcs.com":@"127.0.0.1",
@"cdn.cn.gcloudcs.qq.com":@"127.0.0.1",
@"cdn.hk.gcloud.com":@"127.0.0.1",
@"cdn.hk.gcloud.qq.com":@"127.0.0.1",
@"cdn.hk.gcloudcs.com":@"127.0.0.1",
@"cdn.hk.gcloudcs.qq.com":@"127.0.0.1",
@"hk.voice.gcloud.com":@"127.0.0.1",
@"hk.voice.gcloud.qq.com":@"127.0.0.1",
@"cdn.hk.gcloudcs.com":@"127.0.0.1",
@"hk.voice.gcloudcs.com":@"127.0.0.1",
@"hk.voice.gcloudcs.qq.com":@"127.0.0.1",
@"stats.yl.idealgame.com":@"127.0.0.1",
@"idealgame.com":@"127.0.0.1",

 @"dlied1.tc.qq.com":@"127.0.0.1",
                              @"dlied1.qq.com":@"127.0.0.1",
                              @"dlied1.cdntips.com":@"127.0.0.1",
                              @"dlied1.tcdn.qq.com":@"132.232.201.16",
                              @"dlied1.tc.qq.com":@"132.232.201.16",
                              @"dlied1.tcdn.qq.com":@"172.168.3.3",
                              @"dlied1.tc.qq.com":@"172.168.3.3",
                              @"dlied1.qq.com":@"132.232.173.238",
                              @"dlied1.qq.com":@"132.232.173.229",
                              @"dlied1.tcdn.qq.com":@"47.22.121.29",
                              @"dlied1.tc.qq.com":@"47.22.121.29",
                              @"dlied1.qq.com":@"47.22.121.29",
                              @"dlied1.qq.com":@"132.232.197.87",
                              @"dlied1.qq.com":@"132.232.197.86",
                              @"dlied1.qq.com":@"132.232.197.85",
                              @"dlied1.qq.com":@"132.232.173.238",
                              @"dlied1.qq.com":@"132.232.173.220",
                              @"dlied1.qq.com":@"132.232.173.229",
                              @"dlied1.qq.com":@"132.232.197.87",
                              @"dlied1.qq.com":@"132.232.197.86",
                              @"dlied1.qq.com":@"132.232.197.85",
                              @"dlied1.qq.com":@"47.22.121.29",
                              @"dlied1.qq.com":@"132.232.173.228",
                              @"dlied1.qq.com":@"132.232.173.238",
                              @"dlied1.qq.com":@"132.232.173.220",
                              @"dlied1.qq.com":@"132.232.173.229",
                              };
        
        
        [dns enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSString * _Nonnull obj, BOOL * _Nonnull stop) {
            [configuration resolveHostName:@"key" toIPAddress:@"obj"];
            NSLog(@"%@:%@",key,obj);
            //        *stop = YES;
        }];


    }];
}





@end
