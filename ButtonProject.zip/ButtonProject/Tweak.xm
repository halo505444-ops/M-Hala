#import "Uzumaki.h"

UISwitch * Switch;

%hook IOSViewController
- (void)loadView {
%orig;
time(0) {
UIWindow *sfle;
sfle = [UIApplication sharedApplication].keyWindow;

Switch = [[UISwitch alloc] init];


UIButton *Switchs = [[UIButton alloc]init];
Switchs.frame = CGRectMake(0, 85, 70, 100);
[Switchs addTarget:self action:@selector(buttonDragged:withEvent:) forControlEvents:UIControlEventTouchDragInside];
[sfle addSubview:Switchs];

Switch.frame = CGRectMake(10, 70 , 80, 20);
Switch.backgroundColor = [UIColor clearColor];
Switch.onTintColor = [UIColor colorWithRed: 0.22 green: 0.92 blue: 0.30 alpha: 1.00];
Switch.transform = CGAffineTransformMakeScale(1.0, 1.0);
Switch.layer.cornerRadius = 16;
[Switch addTarget:self action:@selector(GG13:)                forControlEvents:UIControlEventValueChanged];
[Switchs addSubview:Switch];
});
}

%new
- (void)GG13:(UISwitch *)speed {
if ([speed isOn]) {
Offset(0x1OFFSET , 0xBYTE);
}else{
Offset(0x1OFFSET , 0xOrginalByte);
}
}

%new
- (void)buttonDragged:(UIButton *)button withEvent:(UIEvent *)event {
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
}
%end