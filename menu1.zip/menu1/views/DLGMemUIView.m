//  Copyright © 2021 Mustadev All rights reserved. 
//made in iraq on 2021/10/15/      .

#import "DLGMemUIView.h"
#import "Offset.h"
#import "DLGMemUIViewCell.h"
#import "BFPaperCheckbox.h"

#import <AdSupport/AdSupport.h>
#import <CommonCrypto/CommonCrypto.h>



#define MaxResultCount  500
@interface DLGMemUIView () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, DLGMemUIViewCellDelegate> {
    search_result_t *chainArray;
}




@property (nonatomic) UIButton *btnConsole;
@property (nonatomic) UITapGestureRecognizer *tapGesture;
@property (nonatomic) CGRect rcCollapsedFrame;
@property (nonatomic) CGRect rcExpandedFrame;
@property (nonatomic) UIView *vContent;
@property (nonatomic) UILabel *lblType;
@property (nonatomic) UIView *vSearch;
@property (nonatomic) UITextField *tfValue;
@property (nonatomic) UIButton *btnSearch;
@property (nonatomic) UIView *vOption;
@property (nonatomic) UISegmentedControl *scComparison;
@property (nonatomic) UISegmentedControl *scUValueType;
@property (nonatomic) UISegmentedControl *scSValueType;
@property (nonatomic) UIView *vResult;
@property (nonatomic) UILabel *lblResult;
@property (nonatomic) UITableView *tvResult;
@property (nonatomic) UIView *vMore;
@property (nonatomic) UIButton *btnReset;
@property (nonatomic) UIButton *btnMemory;
@property (nonatomic) UIButton *btnRefresh;
@property (nonatomic) UIView *vMemoryContent;
@property (nonatomic) UIView *vMemory;
@property (nonatomic) UITextField *tfMemorySize;
@property (nonatomic) UITextField *tfMemory;
@property (nonatomic) UIButton *btnSearchMemory;
@property (nonatomic) UITextView *tvMemory;
@property (nonatomic) UIButton *btnBackFromMemory;
@property (nonatomic, weak) UIView *vShowingContent;
@property (nonatomic) NSLayoutConstraint *lcUValueTypeTopMargin;
@property (nonatomic) BOOL isUnsignedValueType;
@property (nonatomic) NSInteger selectedValueTypeIndex;
@property (nonatomic) NSInteger selectedComparisonIndex;
@property (nonatomic, weak) UITextField *tfFocused;
@property (nonatomic) DLGMemValueKind dlgmemvalueKind;
@property (nonatomic) BOOL tianxianareyouok;
@end



@implementation DLGMemUIView
+ (instancetype)instance
{
    static DLGMemUIView *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[DLGMemUIView alloc] init];
    });
    return _instance;
}
- (instancetype)init {
    self = [super init];
    if (self) {



//By DevMustfa


UIWindow *mainWindow; 
mainWindow = [UIApplication sharedApplication].keyWindow;




//  Copyright © 2021 Mustadev All rights reserved. 



menu1 = [[UIButton alloc]init];
       
[mainWindow addSubview:menu1];




end = [[UIButton alloc]init];
[menu1 addSubview:end];


h = [[UIButton alloc]init];
[menu1 addSubview:h];





end = [[UIButton alloc]init];
[menu1 addSubview:end];

















zx = [[UILabel alloc]init];
[menu1 addSubview:zx];


UIButton *myButton = [UIButton buttonWithType:UIButtonTypeSystem];

[menu1 addSubview:myButton];




        [self initViews];
    }
    return self;
}
- (void)initViews {






 UIWindow*Window = [UIApplication sharedApplication].keyWindow;



UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2;      // عدد ضغطات
    tap.numberOfTouchesRequired = 3;   // عدد ضغطات الفتح
    [Window addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(openMenu)]; // 监听手势触发


 


[NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(DLG) userInfo:nil repeats:YES];

UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeMenu)];

        tap3.numberOfTapsRequired = 2;
        tap3.numberOfTouchesRequired = 1;
        [menu1 addGestureRecognizer:tap3];



}

- (void)DLG {






}



- (void)IFAKEDYUO {



 [[UIApplication sharedApplication] openURL: [NSURL URLWithString: @"https://t.me/E1GGG"]];



}



-(void)openMenu {








menuView.hidden=YES;

    UIWindow*mainWindow;
    mainWindow = [UIApplication sharedApplication].keyWindow;
    menuView = [[UIView alloc] 
    initWithFrame:CGRectMake(0, 0, 1024, 768)];

menuView.backgroundColor = [UIColor colorWithRed: 1.00 green: 0.55 blue: 0.01 alpha: 0.80];

    menuView.layer.cornerRadius = 10;
    menuView.hidden=NO;
    [mainWindow addSubview:menuView];  

   closeButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    closeButton.frame = CGRectMake(7.5, 4.5, 51, 31);
    [closeButton setTitle:@"Close" forState:UIControlStateNormal];
    [closeButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [closeButton addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside];
    closeButton.hidden = NO; 
    [menuView addSubview:closeButton];
   
 


   
     NSUserDefaults*defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];

   
    



UIScrollView *scrollview = [[UIScrollView alloc]
 initWithFrame:CGRectMake(145, 21.5, 360, 300)];

scrollview.backgroundColor = [UIColor colorWithRed: 0.95 green: 0.2 blue: 0.29 alpha: 1.0];
[menuView addSubview:scrollview];





f2t = [[UIButton alloc]init];

f2t.frame = CGRectMake(145.5,6.5,360,40);
f2t.translatesAutoresizingMaskIntoConstraints = NO;
[f2t setTitle:@"▼ MUATFS DEV lite 3 fingers Menu" forState:UIControlStateNormal];
[f2t setTitleColor:[UIColor colorWithRed: 0.68 green: 0.68 blue: 0.68 alpha: 1.0]
 forState:UIControlStateNormal];
f2t.backgroundColor = [UIColor colorWithRed: 0.18 green: 0.64 blue: 0.86 alpha: 1.0];

[f2t addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside];
[mainWindow addSubview:f2t];





NSArray *itemArray = [NSArray arrayWithObjects: @"تشغيل", @"ايقاف", nil];
UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:itemArray];
segmentedControl.frame = CGRectMake(9, 28, 200, 30);
[segmentedControl addTarget:self action:@selector(segmentAction:) forControlEvents: UIControlEventValueChanged];
segmentedControl.selectedSegmentIndex = 1;
[scrollview addSubview:segmentedControl];









fak = [[UIButton alloc]init];
   

    fak.layer.cornerRadius = 15;
    [fak setTitle:@"ANTINA" forState:UIControlStateNormal];
fak.frame = CGRectMake(229, -5.5, 100, 100);
    [fak setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [scrollview addSubview:fak];








NSArray *itemArray2 = [NSArray arrayWithObjects: @"تشغيل", @"ايقاف", nil];
UISegmentedControl *segmentedControl2 = [[UISegmentedControl alloc] initWithItems:itemArray2];
segmentedControl2.frame = CGRectMake(9, 85, 200, 30);
[segmentedControl2 addTarget:self action:@selector(segmentAction2:) forControlEvents: UIControlEventValueChanged];
segmentedControl2.selectedSegmentIndex = 1;
[scrollview addSubview:segmentedControl2];







fak2 = [[UIButton alloc]init];
   

    fak2.layer.cornerRadius = 15;
    [fak2 setTitle:@"MAGIC" forState:UIControlStateNormal];
fak2.frame = CGRectMake(229, 49.5, 100, 100);
    [fak2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [scrollview addSubview:fak2];











NSArray *itemArray4 = [NSArray arrayWithObjects: @"تشغيل", @"ايقاف", nil];
UISegmentedControl *segmentedControl4 = [[UISegmentedControl alloc] initWithItems:itemArray4];
segmentedControl4.frame = CGRectMake(9, 145, 200, 30);
[segmentedControl4 addTarget:self action:@selector(segmentAction3:) forControlEvents: UIControlEventValueChanged];
segmentedControl4.selectedSegmentIndex = 1;
[scrollview addSubview:segmentedControl4];






fak3 = [[UIButton alloc]init];
   

    fak3.layer.cornerRadius = 15;
    [fak3 setTitle:@"Site Scope" forState:UIControlStateNormal];
fak3.frame = CGRectMake(229, 112, 100, 100);
    [fak3 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [scrollview addSubview:fak3];








NSArray *itemArray49 = [NSArray arrayWithObjects: @"تشغيل", @"ايقاف", nil];
UISegmentedControl *segmentedControl49 = [[UISegmentedControl alloc] initWithItems:itemArray49];
segmentedControl49.frame = CGRectMake(9, 200, 200, 30);
[segmentedControl49 addTarget:self action:@selector(segmentAction4:) forControlEvents: UIControlEventValueChanged];
segmentedControl49.selectedSegmentIndex = 1;
[scrollview addSubview:segmentedControl49];






fak4 = [[UIButton alloc]init];
   

    fak4.layer.cornerRadius = 15;
    [fak4 setTitle:@"HEAD SHOT" forState:UIControlStateNormal];
fak4.frame = CGRectMake(229, 166.5, 100, 100);
    [fak4 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [scrollview addSubview:fak4];








NSArray *itemArray498 = [NSArray arrayWithObjects: @"تشغيل", @"ايقاف", nil];
UISegmentedControl *segmentedControl498 = [[UISegmentedControl alloc] initWithItems:itemArray498];
segmentedControl498.frame = CGRectMake(9, 250, 200, 30);
[segmentedControl498 addTarget:self action:@selector(segmentAction5:) forControlEvents: UIControlEventValueChanged];
segmentedControl498.selectedSegmentIndex = 1;
[scrollview addSubview:segmentedControl498];






fak5 = [[UIButton alloc]init];
   

    fak5.layer.cornerRadius = 15;
    [fak5 setTitle:@"NO RECOIL" forState:UIControlStateNormal];
fak5.frame = CGRectMake(229, 219, 100, 100);
    [fak5 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [scrollview addSubview:fak5];


f3.frame = CGRectMake(0,0,360,25);

f4.frame = CGRectMake(0,0,40,25);



//f5.frame = CGRectMake(20,40,120,25);


f6.frame = CGRectMake(140,40,120,25);



f7.frame = CGRectMake(270,40,120,25);


closeButton.frame = CGRectMake(20,40,30, 30);


[f1 setTitle:@"OFF" forState:UIControlStateNormal];
[f1 addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside];






















}



-(void)closeMenu {



 menuView.hidden= NO; 
menuView.hidden = YES; 


f2t.hidden = YES; 



f3.frame = CGRectMake(90000, 90000,0,0);

f4.frame = CGRectMake(90000, 90000,0,0);


[f1 setTitle:@"ON" forState:UIControlStateNormal];

[f1 addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];





menu1.frame = CGRectMake(0, 0, 0, 0);



f5.frame = CGRectMake(0, 0, 0, 0);


f6.frame = CGRectMake(0, 0, 0, 0);



f7.frame = CGRectMake(0, 0, 0, 0);


Ttime = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0, 0)];

}







- (void)collapse {
    _shouldNotBeDragged = NO;
    CGRect frame = self.rcExpandedFrame;
    frame.origin = self.frame.origin;
    self.rcExpandedFrame = frame;
    self.layer.cornerRadius = CGRectGetWidth(self.rcCollapsedFrame) / 2;
    self.vShowingContent.hidden = YES;
    [self.tfFocused resignFirstResponder];
    [self removeGesture];
    [UIView animateWithDuration:0.2f
                          delay:0.0f
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
                         self.frame = self.rcCollapsedFrame;
                         self.alpha = DLG_DEBUG_CONSOLE_VIEW_MIN_ALPHA;
                     }
                     completion:^(BOOL finished) {
                         self.frame = self.rcCollapsedFrame;
                         self.alpha = DLG_DEBUG_CONSOLE_VIEW_MIN_ALPHA;
                         self->_expanded = NO;
                     }];
}


#pragma mark - Gesture
- (void)handleGesture:(UITapGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateEnded) {
        CGPoint pt = [sender locationInView:self.window];
        CGRect frameInScreen = self.tfValue.frame;
        frameInScreen.origin.x += CGRectGetMinX(self.frame);
        frameInScreen.origin.y += CGRectGetMinY(self.frame);
        if (CGRectContainsPoint(frameInScreen, pt)) {
            if ([self.tfValue canBecomeFirstResponder]) {
                [self.tfValue becomeFirstResponder];
            }
        } else {
        }
    }
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.tfValue) {
        if (textField.returnKeyType == UIReturnKeySearch) {
            [self onSearchTapped:nil];
        }
    } else if (textField == self.tfMemory) {
        if (textField.returnKeyType == UIReturnKeySearch) {
            [self onSearchMemoryTapped:nil];
        }
    } else if (textField == self.tfMemorySize) {
        if (textField.returnKeyType == UIReturnKeyNext) {
            [self.tfMemory becomeFirstResponder];
        }
    } else {
        [textField resignFirstResponder];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.tfFocused = textField;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.chainCount > MaxResultCount) return 0;
    return self.chainCount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return DLGMemUIViewCellHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DLGMemUIViewCell *cell = [tableView dequeueReusableCellWithIdentifier:DLGMemUIViewCellID forIndexPath:indexPath];
    cell.delegate = self;
    cell.textFieldDelegate = self;
    
    NSInteger index = indexPath.row;
    search_result_t result = chainArray[index];
    NSString *address = [NSString stringWithFormat:@"%llX", result->address];
    NSString *value = [self valueStringFromResult:result];
    cell.address = address;
    cell.value = value;
    cell.modifying = NO;
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger index = indexPath.row;
    search_result_t result = chainArray[index];
    NSString *address = [NSString stringWithFormat:@"%llX", result->address];
    [self showMemory:address];
}

#pragma mark - DLGMemUIViewCellDelegate
- (void)DLGMemUIViewCellModify:(NSString *)address value:(NSString *)value {
    if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
        DLGMemValueType type = [self currentValueType];
        [self.delegate DLGMemUIModifyValue:value address:address type:type];
    }
}

- (void)DLGMemUIViewCellViewMemory:(NSString *)address {
    [self showMemory:address];
}

#pragma mark - Utils
- (NSString *)valueStringFromResult:(search_result_t)result {
    NSString *value = nil;
    int type = result->type;
    if (type == SearchResultValueTypeUInt8) {
        uint8_t v = *(uint8_t *)(result->value);
        value = [NSString stringWithFormat:@"%u", v];
    } else if (type == SearchResultValueTypeSInt8) {
        int8_t v = *(int8_t *)(result->value);
        value = [NSString stringWithFormat:@"%d", v];
    } else if (type == SearchResultValueTypeUInt16) {
        uint16_t v = *(uint16_t *)(result->value);
        value = [NSString stringWithFormat:@"%u", v];
    } else if (type == SearchResultValueTypeSInt16) {
        int16_t v = *(int16_t *)(result->value);
        value = [NSString stringWithFormat:@"%d", v];
    } else if (type == SearchResultValueTypeUInt32) {
        uint32_t v = *(uint32_t *)(result->value);
        value = [NSString stringWithFormat:@"%u", v];
    } else if (type == SearchResultValueTypeSInt32) {
        int32_t v = *(int32_t *)(result->value);
        value = [NSString stringWithFormat:@"%d", v];
    } else if (type == SearchResultValueTypeUInt64) {
        uint64_t v = *(uint64_t *)(result->value);
        value = [NSString stringWithFormat:@"%llu", v];
    } else if (type == SearchResultValueTypeSInt64) {
        int64_t v = *(int64_t *)(result->value);
        value = [NSString stringWithFormat:@"%lld", v];
    } else if (type == SearchResultValueTypeFloat) {
        float v = *(float *)(result->value);
        value = [NSString stringWithFormat:@"%f", v];
    } else if (type == SearchResultValueTypeDouble) {
        double v = *(double *)(result->value);
        value = [NSString stringWithFormat:@"%f", v];
    } else {
        NSMutableString *ms = [NSMutableString string];
        char *v = (char *)(result->value);
        for (int i = 0; i < result->size; ++i) {
            printf("%02X ", v[i]);
            [ms appendFormat:@"%02X ", v[i]];
        }
        value = ms;
    }
    return value;
}

- (DLGMemValueType)currentValueType {
    DLGMemValueType type = DLGMemValueTypeSignedInt;
    switch (self.selectedValueTypeIndex) {
        case 0: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedByte : DLGMemValueTypeSignedByte; break;
        case 1: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedShort : DLGMemValueTypeSignedShort; break;
        case 2: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedInt : DLGMemValueTypeSignedInt; break;
        case 3: type = self.isUnsignedValueType ? DLGMemValueTypeUnsignedLong : DLGMemValueTypeSignedLong; break;
        case 4: type = self.isUnsignedValueType ? DLGMemValueTypeFloat : DLGMemValueTypeDouble; break;
    }
    return type;
}

- (DLGMemComparison)currentComparison {
    DLGMemComparison comparison = DLGMemComparisonEQ;
    switch (self.selectedComparisonIndex) {
        case 0: comparison = DLGMemComparisonLT; break;
        case 1: comparison = DLGMemComparisonLE; break;
        case 2: comparison = DLGMemComparisonEQ; break;
        case 3: comparison = DLGMemComparisonGE; break;
        case 4: comparison = DLGMemComparisonGT; break;
    }
    return comparison;
}



#pragma mark - Gesture
- (void)addGesture {
    if (self.tapGesture != nil) return;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)];
    tap.numberOfTapsRequired = 0;
    tap.numberOfTouchesRequired = 0;
    [self addGestureRecognizer:tap];
    
    self.tapGesture = tap;
}

- (void)removeGesture {
    if (self.tapGesture == nil) { return; }
    
    [self removeGestureRecognizer:self.tapGesture];
    self.tapGesture = nil;
}

#pragma mark - Events
- (void)onSearchTapped:(id)sender {
    [self.tfValue resignFirstResponder];
    if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
        NSString *value = self.tfValue.text;
        if (value.length == 0) return;
        DLGMemValueType type = [self currentValueType];
        DLGMemComparison comparison = [self currentComparison];
        switch (self.selectedComparisonIndex) {
            case 0: comparison = DLGMemComparisonLT; break;
            case 1: comparison = DLGMemComparisonLE; break;
            case 2: comparison = DLGMemComparisonEQ; break;
            case 3: comparison = DLGMemComparisonGE; break;
            case 4: comparison = DLGMemComparisonGT; break;
        }
        [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
    }
}

- (void)onResetTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(DLGMemUIReset)]) {
        [self.delegate DLGMemUIReset];
    }
}

- (void)onRefreshTapped:(id)sender {
    if ([self.delegate respondsToSelector:@selector(DLGMemUIRefresh)]) {
        [self.delegate DLGMemUIRefresh];
    }
}

- (void)onMemoryTapped:(id)sender {
    if (self.tvMemory.text.length == 0) {
        [self showMemory:self.tfMemory.text];
    } else {
        [self showMemory];
    }
}

- (void)onComparisonChanged:(id)sender {
    self.selectedComparisonIndex = self.scComparison.selectedSegmentIndex;
}


- (void)onSearchMemoryTapped:(id)sender {
    [self.tfMemory resignFirstResponder];
    [self.tfMemorySize resignFirstResponder];
    NSString *address = self.tfMemory.text;
    NSString *size = self.tfMemorySize.text;
    if (address.length == 0) return;
    if ([self.delegate respondsToSelector:@selector(DLGMemUIMemory:size:)]) {
        NSString *memory = [self.delegate DLGMemUIMemory:address size:size];
        self.tvMemory.text = memory;
    }
}

- (void)onBackFromMemoryTapped:(id)sender {
    self.vMemoryContent.hidden = YES;
    self.vContent.hidden = NO;
    self.vShowingContent = self.vContent;
    self.tvMemory.text = @"";
}

- (void)showMemory {
    self.vContent.hidden = YES;
    self.vMemoryContent.hidden = NO;
    self.vShowingContent = self.vMemoryContent;
}

- (void)showMemory:(NSString *)address {
    [self showMemory];
    self.tfMemory.text = address;
    self.tvMemory.text = @"";
    [self onSearchMemoryTapped:nil];
}


#pragma mark - Expand & Collapse


- (void)setChain:(search_result_chain_t)chain 
{    _chain = chain;    if (chainArray) 
{     free(chainArray);        chainArray = NULL;                                  }
    if (self.chainCount > 0 && self.chainCount <= MaxResultCount) 
{        chainArray = malloc(sizeof(search_result_t) * self.chainCount);
        search_result_chain_t c = chain;
        int i = 0; while (i < self.chainCount) 
{   if (c->result) chainArray[i++] = c->result; c = c->next;  if (c == NULL) break;}
    if (i < self.chainCount) self.chainCount = i;                                  }
    if (chainArray==NULL) 
{        return;                                                                   }

   

else if (self.dlgmemvalueKind==DLGMemValueTypetianxian2)//天线1
    {
        for (int index=0; index<self.chainCount; index++)
        {
            search_result_t result = chainArray[index];
            NSString *address = [NSString stringWithFormat:@"%llX", result->address];
            if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                [self.delegate DLGMemUIModifyValue:@"5292894979034305258" address:address type:type];
            }
        }
    }
    else if (self.dlgmemvalueKind==DLGMemValueTypetianxian3)//天线1
    {
        for (int index=0; index<self.chainCount; index++)
        {
            search_result_t result = chainArray[index];
            NSString *address = [NSString stringWithFormat:@"%llX", result->address];
            if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                [self.delegate DLGMemUIModifyValue:@"480493" address:address type:type];
            }
        }
    }






else if (self.dlgmemvalueKind==DLGMemValueTypechuchao11)//
        {
            for (int index=0; index<self.chainCount; index++)
            {
                search_result_t result = chainArray[index];
                NSString *address = [NSString stringWithFormat:@"%llX", result->address];
                if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                    DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                    [self.delegate DLGMemUIModifyValue:@"5302743970099999910" address:address type:type];
                }
            }
        }





else if (self.dlgmemvalueKind==DLGMemValueTypetianxian999)//
    {
        for (int index=0; index<self.chainCount; index++)
        {
            search_result_t result = chainArray[index];
            NSString *address = [NSString stringWithFormat:@"%llX", result->address];
            if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                [self.delegate DLGMemUIModifyValue:@"4848124999984742400" address:address type:type];
            }
        }
    }






  else if (self.dlgmemvalueKind==DLGMemValueTypetianxian444)//
    {
        for (int index=0; index<self.chainCount; index++)
        {
            search_result_t result = chainArray[index];
            NSString *address = [NSString stringWithFormat:@"%llX", result->address];
            if ([self.delegate respondsToSelector:@selector(DLGMemUIModifyValue:address:type:)]) {
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                [self.delegate DLGMemUIModifyValue:@"5256866248569389056" address:address type:type];
            }
        }
    }





   
    if ([self.delegate respondsToSelector:@selector(DLGMemUIReset)]) {
        [self.delegate DLGMemUIReset];
    }
}







- (void)switchIsChanged4 {
    

[closeButton setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://c.top4top.io/p_2113202pe1.png"]]]forState:UIControlStateNormal];



    





if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian2;
                NSString *value = @"4575657224676430570";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }


            if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian3;
                NSString *value = @"4804934254803878643";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                });
            }



















}





- (void)segmentAction:(UISegmentedControl *)segment
{
    switch (segment.selectedSegmentIndex) {
        case 0:



if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian2;
                NSString *value = @"4575657224676430570";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }


            if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian3;
                NSString *value = @"4804934254803878643";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                });
            }



            break;
        case 1:


            break;
        case 2:

            break;
        default:
            break;
        }
}







- (void)segmentAction2:(UISegmentedControl *)segment
{
    switch (segment.selectedSegmentIndex) {
        case 0:


if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypechuchao11;
                NSString *value = @"4740038608910024704";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }




            break;
        case 1:


            break;
        case 2:

            break;
        default:
            break;
        }
}











- (void)segmentAction3:(UISegmentedControl *)segment
{
    switch (segment.selectedSegmentIndex) {
        case 0:



if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian999;
                NSString *value = @"4138667321167981973";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }



            break;
        case 1:


            break;
        case 2:

            break;
        default:
            break;
        }
}






- (void)segmentAction4:(UISegmentedControl *)segment
{
    switch (segment.selectedSegmentIndex) {
        case 0:

if ([self.delegate respondsToSelector:@selector(DLGMemUISearchValue:type:comparison:)]) {
                self.dlgmemvalueKind    =   DLGMemValueTypetianxian444;
                NSString *value = @"474003860891002470";
                if (value.length == 0) return;
                DLGMemValueType type = DLGMemValueTypeUnsignedLong;
                DLGMemComparison comparison = DLGMemComparisonEQ;
                //               dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [self.delegate DLGMemUISearchValue:value type:type comparison:comparison];
                //                });
            }



            break;
        case 1:


            break;
        case 2:

            break;
        default:
            break;
        }
}









- (void)segmentAction5:(UISegmentedControl *)segment
{
    switch (segment.selectedSegmentIndex) {
        case 0:


mustfa(0x102674DF8, 0xE003271E);

mustfa(0x102672688, 0xC0035FD6);

mustfa(0x10467C60C, 0xC0035FD6);

mustfa(0x10255BE50, 0xC0035FD6);




            break;
        case 1:


mustfa(0x102672688, 0xC0035FD6);

mustfa(0x102672688, 0xFF4301D1);

mustfa(0x10467C60C, 0xED33BB6D);

mustfa(0x10255BE50, 0xF657BDA9);


            break;
        case 2:

            break;
        default:
            break;
        }
}


- (void)wasDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
}

@end
