#import <UIKit/UIKit.h>
#import "DLGMemUIViewDelegate.h"
#include "search_result_def.h"

#define DLG_DEBUG_CONSOLE_VIEW_SIZE 50//图标大小

#define DLG_DEBUG_CONSOLE_VIEW_MIN_ALPHA 0.5f//图标半径
#define DLG_DEBUG_CONSOLE_VIEW_MAX_ALPHA 0.8f//图标半径

//  Copyright © 2021 Mustadev All rights reserved. 
UIButton *fak5;
UIButton *fak4;
UIButton *fak3;
UIButton *fak2;
UIButton *fak;
UIButton *menu2;
UIButton *menu1;
UIButton *h;
UIScrollView *qq;
UISwitch *aa;
UISwitch *bb;
UISwitch *cc;
UISwitch *dd;
UISwitch *ee;
UISwitch *ff;
UISwitch *gg;
UISwitch *hh;
UISwitch *ahmed;
UISwitch *ahmed1;
UISwitch *ahmed2;
UISwitch *ahmed3;
UISwitch *ahmed4;
UISwitch *ahmed5;
UISwitch *ahmed6;
UISwitch *ahmed7;
UILabel *zx;
UILabel *zc;
UILabel *zv;
UILabel *zb;
UILabel *zn;
UILabel *zm;
UILabel *za;
UILabel *zs;
UILabel *zd;
UILabel *zf;
UILabel *zg;
UILabel *zh;
UILabel *zj;
UILabel *zk;
UILabel *zl;
UILabel *zq;
UIButton *end;


UIButton *f1;

UIButton *f2t;

UIButton *f3;

UIButton *f4;

UIButton *f5;

UIButton *f6;

UIButton *f7;

UILabel *salman;

UIButton *lin;

UILabel *Ttime;
NSDateFormatter *ttime;
UIDevice *myDevice;


UIButton *myButton;
UIButton *line;
UIScrollView *scrollview;
UIButton *closeButton;
UIView *menuView;



@interface DLGMemUIView : UIView




@property (nonatomic) id<DLGMemUIViewDelegate> delegate;
@property (nonatomic) UIWindow *window;
@property (nonatomic, readonly) BOOL shouldNotBeDragged;
@property (nonatomic, readonly) BOOL expanded;

@property (nonatomic) NSInteger chainCount;
@property (nonatomic) search_result_chain_t chain;

+ (instancetype)instance;


@end
