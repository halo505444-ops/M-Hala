#import "E1GGG.h"
#import "Mustfa/DLGMemUIView.h"

//antiban
%hook UIApplication
-(void)finishedTest:(id)arg1 extraResults:(id)arg2 {
%orig;


//اضف حمايه هنا 
  




}


%end