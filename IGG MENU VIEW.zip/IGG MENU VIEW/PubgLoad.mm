//
//  PubgLoad.m
//  pubg
//
//  Created by MUSTFADEV https://iosdev.net
//

#import "PubgLoad.h"
#import <UIKit/UIKit.h>

#import "JHPP.h"
#import "JHDragView.h"
#import "SCLAlertView/SCLAlertView.h"
#import <Foundation/Foundation.h>
#import <mach-o/dyld.h>
#import <UIKit/UIKit.h>
#import <sys/sysctl.h>
#import <objc/runtime.h>
#import <CFNetwork/CFNetwork.h>
#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AudioToolbox/AudioToolbox.h>


NSString *feature1 = @"𝐀𝐍𝐓𝐄𝐍𝐍𝐀 1";
NSString *feature2 = @"𝐀𝐍𝐓𝐄𝐍𝐍𝐀 2";
NSString *feature3 = @"𝐌𝐀𝐆𝐈𝐂-𝐁";
NSString *feature4 = @"𝐒𝐓𝐀𝐍𝐃-𝐒";
NSString *feature5 = @"𝐀𝐕𝐎𝐈𝐃 🛡";
NSString *feature6 = @"𝐒𝐎𝐎𝐍";

NSString *feature7 = @"𝐒-𝐂𝐑𝐎𝐒𝐒";
NSString *feature8 = @"𝐍𝐎 𝐑𝐄𝐂𝐎𝐈𝐋";
NSString *feature9 = @"𝐀𝐈𝐌𝐁𝐎𝐓";
NSString *feature10 = @"𝐅𝐀𝐒𝐓 𝐌𝐎𝐕𝐄";
NSString *feature11 = @"𝐒𝐏𝐄𝐄𝐃";
NSString *feature12 = @"𝐇𝐈𝐃𝐄 𝐅𝐎𝐆";
UIButton *But;
UIButton *gg;
UIButton *menu1;
UIButton *h;
UIScrollView *qq;
UISwitch *aa;
UISwitch *tr;
UISwitch *bb;
UISwitch *cc;
UISwitch *dd;
UISwitch *ee;
UISwitch *ff;
UISwitch *uu;
UISwitch *uz;
UISwitch *ii;
UISwitch *ll;
UISwitch *ss;
UISwitch *pp;
UISwitch *vv;
UIButton *zu;
UIButton *zi;
UIButton *zl;
UIButton *zs;
UIButton *zp;
UIButton *zd;
UIButton *zx;
UIButton *zk;
UIButton *zc;
UIButton *zv;
UIButton *zb;
UIButton *zn;
UIButton *zm;
UIButton *zz;
UIButton *lin;
UIButton *lin2;
UIButton *yq;
UIButton *sub;
UILabel *timeForm;
UILabel *dateForm;
UILabel *bateryDevi;
NSDateFormatter *dateU;
NSDateFormatter *timeR;
UIDevice *myDevice;
UILabel *Ttime;
NSDateFormatter *ttime;

UIWindow *mainWindow;


@interface PubgLoad()
@end

@implementation PubgLoad


static PubgLoad *extraInfo;
static BOOL MenDeal;



+ (void)load
{



    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(13* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        extraInfo =  [PubgLoad new];
        [extraInfo iniview];
        [extraInfo initTapGes];
        [extraInfo label];
        [extraInfo Update];
            });
    
}


- (void)Update {
    
    
myDevice = [UIDevice currentDevice];
[myDevice setBatteryMonitoringEnabled:YES];
double batLeft = (float)[myDevice batteryLevel] * 100;

Ttime.text = [NSString stringWithFormat:@"𝔇ℜ𝔄𝔊𝔒𝔑 𝗛𝗔𝗖𝗞 %@ • %0.0f🔋 ",[ttime stringFromDate:[NSDate date]],batLeft];

}

-(void)initTapGes
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2;//点击次数
    tap.numberOfTouchesRequired = 3;//手指数
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(iniview)];
}
- (void)label {

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
mainWindow = [UIApplication sharedApplication].keyWindow;



        myDevice = [UIDevice currentDevice];
        [myDevice setBatteryMonitoringEnabled:YES];
        double batLeft = (float)[myDevice batteryLevel] * 100;

        ttime = [[NSDateFormatter alloc] init];
        [ttime setDateFormat:@"yyyy/MM/dd • hh:mm:ss"];

        Ttime = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 4 - 5, 0, [UIScreen mainScreen].bounds.size.width / 2  + 10, 20)];
        Ttime.font = [UIFont fontWithName:@"TimesNewRomanPS-BoldMT" size:10.0];
    Ttime.backgroundColor = [UIColor colorWithRed: 0.00 green: 0.00 blue: 0.00 alpha: 0.40];
        Ttime.layer.cornerRadius = 15;
        Ttime.textAlignment = NSTextAlignmentCenter;
        
        Ttime.layer.masksToBounds = true;


        Ttime.text = [NSString stringWithFormat:@"𝔇ℜ𝔄𝔊𝔒𝔑 𝗛𝗔𝗖𝗞 %@  %0.0f🔋 ",[ttime stringFromDate:[NSDate date]],batLeft];

        Ttime.textColor = [UIColor whiteColor];
        [mainWindow addSubview:Ttime];

        [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(Update) userInfo:nil repeats:YES];







menu1 = [[UIButton alloc]init];
        [menu1 addTarget:self action:@selector(wasDragged:withEvent:)
    forControlEvents:UIControlEventTouchDragInside];
[mainWindow addSubview:menu1];



h = [[UIButton alloc]init];
[menu1 addSubview:h];

But = [[UIButton alloc]init];

[menu1 addSubview:But];

//timers






   
aa = [[UISwitch alloc]init];
aa.frame = CGRectMake(9000,9000,0,0);
    [aa addTarget:self                action:@selector(switchIsChanged:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:aa];


bb = [[UISwitch alloc]init];
bb.frame = CGRectMake(9000,9000,0,0);
    [bb addTarget:self                action:@selector(switchIsChanged1:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:bb];


cc = [[UISwitch alloc]init];
cc.frame = CGRectMake(9000,9000,0,0);
    [cc addTarget:self                action:@selector(switchIsChanged2:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:cc];


dd = [[UISwitch alloc]init];
dd.frame = CGRectMake(9000,9000,0,0);
    [dd addTarget:self                action:@selector(switchIsChanged3:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:dd];

ee = [[UISwitch alloc]init];
ee.frame = CGRectMake(9000,9000,0,0);
    [ee addTarget:self                action:@selector(switchIsChanged4:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:ee];


ff = [[UISwitch alloc]init];
ff.frame = CGRectMake(9000,9000,0,0);
    [ff addTarget:self                action:@selector(switchIsChanged5:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:ff];



//start


 uu = [[UISwitch alloc]init];
uu.frame = CGRectMake(9000,9000,0,0);
    [uu addTarget:self                action:@selector(switchIsChanged6:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:uu];
    
    uz = [[UISwitch alloc]init];
    uz.frame = CGRectMake(9000,9000,0,0);
        [uz addTarget:self                action:@selector(switchIsChanged12:)                forControlEvents:UIControlEventValueChanged];
    [menu1 addSubview:uz];


ii = [[UISwitch alloc]init];
ii.frame = CGRectMake(9000,9000,0,0);
    [ii addTarget:self                action:@selector(switchIsChanged7:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:ii];


ll = [[UISwitch alloc]init];
ll.frame = CGRectMake(9000,9000,0,0);
    [ll addTarget:self                action:@selector(switchIsChanged8:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:ll];


ss = [[UISwitch alloc]init];
ss.frame = CGRectMake(9000,9000,0,0);
    [ss addTarget:self                action:@selector(switchIsChanged9:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:ss];

pp = [[UISwitch alloc]init];
pp.frame = CGRectMake(9000,9000,0,0);
    [pp addTarget:self                action:@selector(switchIsChanged10:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:pp];

vv = [[UISwitch alloc]init];
vv.frame = CGRectMake(9000,9000,0,0);
    [vv addTarget:self                action:@selector(switchIsChanged11:)                forControlEvents:UIControlEventValueChanged];
[menu1 addSubview:vv];



//end



zu = [[UIButton alloc]init];
[menu1 addSubview:zu];

zi = [[UIButton alloc]init];
[menu1 addSubview:zi];

zl = [[UIButton alloc]init];
[menu1 addSubview:zl];

zs = [[UIButton alloc]init];
[menu1 addSubview:zs];

zp = [[UIButton alloc]init];
[menu1 addSubview:zp];

zd = [[UIButton alloc]init];
[menu1 addSubview:zd];
    



zx = [[UIButton alloc]init];
[menu1 addSubview:zx];
    
    zk = [[UIButton alloc]init];
    [menu1 addSubview:zk];


zc = [[UIButton alloc]init];
[menu1 addSubview:zc];

zv = [[UIButton alloc]init];
[menu1 addSubview:zv];

zb = [[UIButton alloc]init];
[menu1 addSubview:zb];

zn = [[UIButton alloc]init];
[menu1 addSubview:zn];

zm = [[UIButton alloc]init];
[menu1 addSubview:zm];





lin = [[UIButton alloc]init];
[menu1 addSubview:lin];

lin2 = [[UIButton alloc]init];
[menu1 addSubview:lin2];

yq =[[UIButton alloc]init];
[menu1 addSubview:yq];

    });

}


- (void)iniview
{
    
    JHDragView *view = [[JHPP currentViewController].view viewWithTag:100];
    if (!view) {
        view = [[JHDragView alloc] init];
        view.tag = 100;
        [[JHPP currentViewController].view addSubview:view];

        //调用函数
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onConsoleButtonTapped)];
        tap.numberOfTapsRequired = 1;
        [view addGestureRecognizer:tap];
        
        

    }
    if (!MenDeal) {
        view.hidden = NO;
    } else {
        view.hidden = YES;
    }
    
    MenDeal = !MenDeal;
}

-(void)onConsoleButtonTapped//:(id)sender
{

    UIWindow *mainWindow;
mainWindow = [UIApplication sharedApplication].keyWindow;

/*

  [oo addTarget:self action:@selector(consoleButtonTapped:) forControlEvents:UIControlEventTouchUpInside];


        SCLAlertView *alertxxxxxxxxxxxxx = [[SCLAlertView alloc] initWithNewWindow];
        self.dlgmemvalueKind    =   DLGMemValueTypexiugaiqi;
        [self shoudonggaima];

alertxxxxxxxxxxxxx.shouldDismissOnTapOutside    =   YES;

*/
 menu1.transform = CGAffineTransformMakeScale(1.0, 1.0);
                            
menu1.alpha = 1.00;
    menu1.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 4 - 10, 30, [UIScreen mainScreen].bounds.size.width / 2  + 20, 325);
    menu1.backgroundColor = [UIColor colorWithRed: 0.11 green: 0.11 blue: 0.11 alpha: 1.0];
menu1.alpha=1;
But.frame = CGRectMake(0, 1, 300, 30);


menu1.layer.cornerRadius = 20;



            


qq.frame = CGRectMake(175, 45, 319, 250);
aa.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 25 - 5, 55, [UIScreen mainScreen].bounds.size.width / 5  + 10, 3);
    aa.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
bb.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 25 - 5, 95, [UIScreen mainScreen].bounds.size.width / 5  + 10, 3);
bb.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
cc.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 25 - 5, 135, [UIScreen mainScreen].bounds.size.width / 5  + 10, 3);
cc.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
dd.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 25 - 5, 175, [UIScreen mainScreen].bounds.size.width / 5  + 10, 3);
dd.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
ee.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 25 - 5, 215, [UIScreen mainScreen].bounds.size.width / 5  + 10, 3);
ee.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
ff.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 25 - 5, 255, [UIScreen mainScreen].bounds.size.width / 5  + 10, 3);
ff.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];


aa.onTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
bb.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];
cc.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];

dd.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];

ee.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];
ff.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];







uu.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.3 - 5, 55, [UIScreen mainScreen].bounds.size.width / 9  + 10, 3);
uz.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.3 - 5, 95, [UIScreen mainScreen].bounds.size.width / 9  + 10, 3);
ll.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.3 - 5, 135, [UIScreen mainScreen].bounds.size.width / 9  + 10, 3);
ss.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.3 - 5, 175, [UIScreen mainScreen].bounds.size.width / 9  + 10, 3);
pp.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.3 - 5, 215, [UIScreen mainScreen].bounds.size.width / 9  + 10, 3);
vv.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.3 - 5, 255, [UIScreen mainScreen].bounds.size.width / 9  + 10, 3);

uu.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
uz.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];

ll.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];

ss.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];

pp.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];

vv.thumbTintColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];




uu.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];
uz.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];


ll.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];

ss.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];

pp.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];
vv.onTintColor = [UIColor colorWithRed: 0.64 green: 0.67 blue: 0.35 alpha: 1.00];


uu.transform = CGAffineTransformMakeScale(0.9, 0.9);
uz.transform = CGAffineTransformMakeScale(0.9, 0.9);

ll.transform = CGAffineTransformMakeScale(0.9, 0.9);
ss.transform = CGAffineTransformMakeScale(0.9, 0.9);
pp.transform = CGAffineTransformMakeScale(0.9, 0.9);
vv.transform = CGAffineTransformMakeScale(0.9, 0.9);




aa.transform = CGAffineTransformMakeScale(0.9, 0.9);
bb.transform = CGAffineTransformMakeScale(0.9, 0.9);
cc.transform = CGAffineTransformMakeScale(0.9, 0.9);
dd.transform = CGAffineTransformMakeScale(0.9, 0.9);
ee.transform = CGAffineTransformMakeScale(0.9, 0.9);
ff.transform = CGAffineTransformMakeScale(0.9, 0.9);



[zx.titleLabel setFont: [zx.titleLabel.font fontWithSize: 9.0]];
zx.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zx setTitle:[NSString stringWithFormat:@"𝗪𝗔𝗟𝗟𝗛𝗔𝗖𝗞"] forState:UIControlStateNormal];
    zx.layer.cornerRadius = 15;
    [mainWindow addSubview:zx];
    
    
        [zx setTitleColor:[UIColor whiteColor]
forState:UIControlStateNormal];
zx.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 3.5 - 5, 60, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zx];
    
    [zk.titleLabel setFont: [zk.titleLabel.font fontWithSize: 9.0]];
    zk.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
        [zk setTitle:[NSString stringWithFormat:@"𝗜𝗡𝗦𝗧𝗔𝗡𝗧𝗛𝗘𝗔𝗗"] forState:UIControlStateNormal];
        zk.layer.cornerRadius = 15;
        [mainWindow addSubview:zk];
        
        
            [zk setTitleColor:[UIColor whiteColor]
    forState:UIControlStateNormal];
    zk.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 3.5 - 5, 100, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
    [menu1 addSubview:zk];
    
    

[zc.titleLabel setFont: [zc.titleLabel.font fontWithSize: 9.0]];
zc.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zc setTitle:[NSString stringWithFormat:@"𝗙𝗔𝗦𝗧𝗕𝗨𝗟𝗟𝗘𝗧"] forState:UIControlStateNormal];
    zc.layer.cornerRadius = 15;
    [mainWindow addSubview:zc];
    
    
        [zc setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zc.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 3.5 - 5, 140, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zc];


[zv.titleLabel setFont: [zv.titleLabel.font fontWithSize: 9.0]];
zv.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zv setTitle:[NSString stringWithFormat:@"𝗜𝗡𝗦𝗧𝗔𝗡𝗧𝗛𝗜𝗧"] forState:UIControlStateNormal];
    zv.layer.cornerRadius = 15;
    [mainWindow addSubview:zv];
    
    
        [zv setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zv.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 3.5 - 5, 180, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zv];


[zb.titleLabel setFont: [zb.titleLabel.font fontWithSize: 9.0]];
zb.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zb setTitle:[NSString stringWithFormat:@"𝗦𝗜𝗧 𝗦𝗖𝗢𝗣𝗘"] forState:UIControlStateNormal];
    zb.layer.cornerRadius = 15;
    [mainWindow addSubview:zb];
    
    
        [zb setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zb.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 3.5 - 5, 220, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zb];

[zn.titleLabel setFont: [zn.titleLabel.font fontWithSize: 9.0]];
zn.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zn setTitle:[NSString stringWithFormat:@"𝗦𝗧𝗔𝗡𝗗 𝗦𝗖𝗢𝗣𝗘"] forState:UIControlStateNormal];
    zn.layer.cornerRadius = 15;
    [mainWindow addSubview:zn];
    
    
        [zn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 3.5 - 5, 260, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zn];



gg = [[UIButton alloc]init];

gg.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 2.5 - 5, 10, [UIScreen mainScreen].bounds.size.width / 5  + 10, 25);


gg.translatesAutoresizingMaskIntoConstraints = NO;
    [gg setTitle:@"𝗫" forState:UIControlStateNormal];
    [gg setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];



   [gg addTarget:self action:@selector(consoleButtonTapped:) forControlEvents:UIControlEventTouchUpInside];

//oo.backgroundColor = [UIColor blackColor];




[menu1 addSubview:gg];

[zu.titleLabel setFont: [zu.titleLabel.font fontWithSize: 9.0]];
zu.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zu setTitle:[NSString stringWithFormat:@"𝗔𝗡𝗧𝗘𝗡𝗡𝗔"] forState:UIControlStateNormal];
    zu.layer.cornerRadius = 15;
    [mainWindow addSubview:zu];
    
    
        [zu setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zu.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8 - 5, 60, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zu];

[zi.titleLabel setFont: [zi.titleLabel.font fontWithSize: 9.0]];
zi.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zi setTitle:[NSString stringWithFormat:@"𝗠𝗔𝗚𝗜𝗖"] forState:UIControlStateNormal];
    zi.layer.cornerRadius = 15;
    [mainWindow addSubview:zi];
    
    
        [zi setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zi.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8 - 5, 100, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zi];


[zl.titleLabel setFont: [zl.titleLabel.font fontWithSize: 9.0]];
zl.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zl setTitle:[NSString stringWithFormat:@"𝗠𝗔𝗚𝗜𝗖 𝟮"] forState:UIControlStateNormal];
    zl.layer.cornerRadius = 15;
    [mainWindow addSubview:zl];
    
    
        [zl setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zl.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8 - 5, 140, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zl];

[zs.titleLabel setFont: [zs.titleLabel.font fontWithSize: 9.0]];
zs.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zs setTitle:[NSString stringWithFormat:@"𝗠𝗔𝗚𝗜𝗖 𝟯"] forState:UIControlStateNormal];
    zs.layer.cornerRadius = 15;
    [mainWindow addSubview:zs];
    
    
        [zs setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zs.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8 - 5, 180, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zs];

[zp.titleLabel setFont: [zp.titleLabel.font fontWithSize: 9.0]];
zp.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zp setTitle:[NSString stringWithFormat:@"𝗔𝗜𝗠"] forState:UIControlStateNormal];
    zp.layer.cornerRadius = 15;
    [mainWindow addSubview:zp];
    
    
        [zp setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zp.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8 - 5, 220, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zp];

[zd.titleLabel setFont: [zd.titleLabel.font fontWithSize: 9.0]];
    zd.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];
    [zd setTitle:[NSString stringWithFormat:@"𝗦𝗟𝗜𝗗𝗘𝗥𝗧𝗥𝗘𝗘"] forState:UIControlStateNormal];
    zd.layer.cornerRadius = 15;
    [mainWindow addSubview:zd];
    
    
        [zd setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
zd.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8 - 5, 260, [UIScreen mainScreen].bounds.size.width / 9  + 10, 25);
[menu1 addSubview:zd];


    [yq setTitle:[NSString stringWithFormat:@" ZANKAL IOS"] forState:UIControlStateNormal];
    yq.layer.cornerRadius = 10;
    [mainWindow addSubview:yq];
    
    
        [yq setTitleColor:[UIColor colorWithRed: 0.97 green: 0.97 blue: 0.97 alpha: 1.00] forState:UIControlStateNormal];
yq.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 6 - 5, 10, [UIScreen mainScreen].bounds.size.width / 4  + 10, 25);
[menu1 addSubview:yq];

sub = [[UIButton alloc]init];


[sub.titleLabel setFont: [sub.titleLabel.font fontWithSize: 7.0]];

sub.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 7 - 5, 300, [UIScreen mainScreen].bounds.size.width / 4  + 10, 25);

    [sub setTitle:@" 𝗖𝗢𝗣𝗬 𝗥𝗜𝗚𝗛𝗧 𝗔𝗟𝗟 ؛ ZANKAL IOS ©" forState:UIControlStateNormal];
    [sub setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
[menu1 addSubview:sub];


lin.frame = CGRectMake([UIScreen mainScreen].bounds.size.width / 8.7 - 5, 35, [UIScreen mainScreen].bounds.size.width / 3  + 10, 3);
lin.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.0 blue: 0.0 alpha: 1.0];

/*
[UIDevice currentDevice].batteryMonitoringEnabled = YES;

int currentBattery = [[UIDevice currentDevice] batteryLevel] *100;
*/









    




/*
NSString * levelLabel = [NSString stringWithFormat:@"NAI| %.f%%", batLeft];
//lblLevel.text = levelLabel;
*/
    







/*

 
*/


/*
gg.frame = CGRectMake(230,0,45,30);

gg.translatesAutoresizingMaskIntoConstraints = NO;
    [gg setTitle:@"OFF" forState:UIControlStateNormal];
    [gg setTitleColor:[UIColor redColor] forState:UIControlStateNormal];

gg.layer.shadowColor = [UIColor redColor].CGColor;

   [gg addTarget:self action:@selector(consoleButtonTapped:) forControlEvents:UIControlEventTouchUpInside];

*/


}

- (void)consoleButtonTapped:(id)sender {
UIWindow *mainWindow;
mainWindow = [UIApplication sharedApplication].keyWindow;







uu.frame = CGRectMake(90000, 90000, 0, 0);
uz.frame = CGRectMake(90000, 90000, 0, 0);
ii.frame = CGRectMake(90000, 90000, 0, 0);
ll.frame = CGRectMake(90000, 90000, 0, 0);
ss.frame = CGRectMake(90000, 90000, 0, 0);
pp.frame = CGRectMake(90000, 90000, 0, 0);
vv.frame = CGRectMake(90000, 90000, 0, 0);
menu1.transform = CGAffineTransformMakeScale(0.7, 0.7);
menu1.alpha = 0.10;
menu1.frame = CGRectMake(0, 0, 0, 0);
h.frame = CGRectMake(90000, 90000, 0, 0);
qq.frame = CGRectMake(90000, 90000, 0, 0);
aa.frame = CGRectMake(90000, 90000, 0, 0);
bb.frame = CGRectMake(90000, 90000, 0, 0);
cc.frame = CGRectMake(90000, 90000, 0, 0);
dd.frame = CGRectMake(90000, 90000, 0, 0);
ee.frame = CGRectMake(90000, 90000, 0, 0);
ff.frame = CGRectMake(90000, 90000, 0, 0);
zx.frame = CGRectMake(0, 0, 0, 0);
zk.frame = CGRectMake(0, 0, 0, 0);
zc.frame = CGRectMake(0, 0, 0, 0);
zv.frame = CGRectMake(0, 0, 0, 0);
zb.frame = CGRectMake(0, 0, 0, 0);
zn.frame = CGRectMake(0, 0, 0, 0);
zm.frame = CGRectMake(0, 0, 0, 0);

zu.frame = CGRectMake(0, 0, 0, 0);
zi.frame = CGRectMake(0, 0, 0, 0);
zl.frame = CGRectMake(0, 0, 0, 0);
zs.frame = CGRectMake(0, 0, 0, 0);
zp.frame = CGRectMake(0, 0, 0, 0);
zd.frame = CGRectMake(0, 0, 0, 0);

lin.frame = CGRectMake(0,0,0,0);
lin2.frame = CGRectMake(0,0,0,0);
yq.frame = CGRectMake(0,0,0,0);


}


- (void)wasDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
}





- (void)switchIsChanged:(UISwitch *)feature1 {
    


    if ([feature1 isOn]) {


        
        




}else{


}
}




 - (void)switchIsChanged1:(UISwitch *)feature2 {
    


    if ([feature2 isOn]) {


        
}else{



}
}



 - (void)switchIsChanged2:(UISwitch *)feature3 {


    
    if ([feature3 isOn]) {


        
        
            
             
}else{



}
}





 - (void)switchIsChanged3:(UISwitch *)feature4 {


    
    if ([feature4 isOn]) {


        


}else{




}
}





 - (void)switchIsChanged4:(UISwitch *)feature5 {
    


    if ([feature5 isOn]) {


        




}else{


}
}

 - (void)switchIsChanged5:(UISwitch *)feature6 {
    


    if ([feature6 isOn]) {


        

}else{


}
}



 - (void)switchIsChanged6:(UISwitch *)feature7 {
    


if ([feature7 isOn]) {

    

}else{




}
}






 - (void)switchIsChanged7:(UISwitch *)feature8 {
    


    if ([feature8 isOn]) {
        
        
        


        



}
}




 - (void)switchIsChanged8:(UISwitch *)feature9 {


    
    if ([feature9 isOn]) {

        
        


}else{
 



}
}




 - (void)switchIsChanged9:(UISwitch *)feature10 {
    


    if ([feature10 isOn]) {
 
       

}else{


}
}




 - (void)switchIsChanged10:(UISwitch *)feature11 {


    
    if ([feature11 isOn]) {

        
        
               
        //    }]];


}else{


}
}





 - (void)switchIsChanged11:(UISwitch *)feature12 {
    


    if ([feature12 isOn]) {

        

}else{



}
}




 - (void)switchIsChanged12:(UISwitch *)feature13 {


    
    if ([feature13 isOn]) {

           
        

}else{



        
}
}



@end
