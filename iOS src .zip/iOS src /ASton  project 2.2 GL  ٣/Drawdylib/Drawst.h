

#import <UIKit/UIKit.h>
#import "JFFloatingMenuView.h"

NS_ASSUME_NONNULL_BEGIN


@interface JFOverlayView : UIView
@property (nonatomic, assign) bool isplay;
@property (nonatomic, assign) bool isStartTimer;
@property (nonatomic, assign) bool isShowMenu;
@property (nonatomic, assign) bool Noscrren;
@property (nonatomic, assign) bool isBulletTrack1;
@property (nonatomic, assign) bool isBulletTrack2;
@property (nonatomic, assign) bool show_hit;
@property (nonatomic, assign) bool isLineEsp;
@property (nonatomic, assign) bool isLineEsp1;
@property (nonatomic, assign) bool isBoxEsp;
@property (nonatomic, assign) bool isHpBarEsp;
@property (nonatomic, assign) bool isTextEsp;
@property (nonatomic, assign) bool isBoneEsp;
@property (nonatomic, assign) bool isTeamMateEsp;
@property (nonatomic, assign) int espDistance;
@property (nonatomic, assign) int test;
@property (nonatomic, assign) int test2;
@property (nonatomic, assign) bool isAimbot;
@property (nonatomic, assign) bool isAimbot2;
@property (nonatomic, assign) bool displayLabel;
@property (nonatomic, assign) bool isBulletTrack;
@property (nonatomic, assign) bool isNorecoil;


@property (nonatomic, assign) float isNorecoil1;
@property (nonatomic, assign) int isNorecoil2;






@property (nonatomic, assign) bool isinstahaed;
@property (nonatomic, assign) bool islaed1;
@property (nonatomic, assign) bool isFov;
@property (nonatomic, assign) bool isNearDeathNotAim;
@property (nonatomic, assign) int aimbotPart;
@property (nonatomic, assign) int amichest;
@property (nonatomic, assign) int aimbotRadius;
@property (nonatomic, assign) int espit;
@property (nonatomic, assign) int itxt;
@property (nonatomic, assign) bool islinebb;
@property (nonatomic, assign) bool show_Magic;
@property (nonatomic, assign) bool isShowProps;
@property (nonatomic, assign) bool isShowPropsVehicle;
@property (nonatomic, assign) bool isShowPropsWeapon;
@property (nonatomic, assign) bool isShowPropsArmor;
@property (nonatomic, assign) bool isShowPropsSight;
@property (nonatomic, assign) bool isAuto;
@property (nonatomic, assign) bool isShowProps6x;
@property (nonatomic, assign) bool isShowProps8x;
@property (nonatomic, assign) bool isShowProps4x;

@property (nonatomic, assign) int RadarMapX;
@property (nonatomic, assign) int RadarMapY;

@property (nonatomic, assign) bool isShowPropsAccessory;
@property (nonatomic, assign) bool isShowPropsBullet;
@property (nonatomic, assign) bool isShowPropsDrug;
@property (nonatomic, assign) bool BoxWith;
@property (nonatomic, assign) bool BPc;
@property (nonatomic, assign) bool Pistol;
@property (nonatomic, assign) bool isShowPropsEarlyWarning;
@property (nonatomic, assign) int propsDistance;
@property (nonatomic, assign) bool show_Instant;
@property (nonatomic, assign) bool isAdsAimbot;
@property (nonatomic, assign) bool isGunAimbot;
@property (nonatomic, assign) bool isShowPropsM416;
@property (nonatomic, assign) bool isShowPropsakm;
@property (nonatomic, assign) bool isShowPropsSCAR;
@property (nonatomic, assign) bool isShowPropsQBZ;
@property (nonatomic, assign) bool hit1;
@property (nonatomic, assign) bool isShowPropsVLA;
@property (nonatomic, assign) bool isShowPropsM7;
@property (nonatomic, assign) bool isShowPropsVector;

@property (nonatomic, assign) int test88;
@property (nonatomic, assign) int test99;

@property (nonatomic, assign) int Aim;



@property (nonatomic, assign) int AimRR;
@property (nonatomic, assign) int AimRRR;
@property (nonatomic, assign) int Testspeed3;
@property (nonatomic, assign) int Testspeed4;
@property (nonatomic, assign) int FPS;
@property (nonatomic, assign) int isZoom;
@property (nonatomic, assign) int Aim1;
@property (nonatomic, assign) int Aim2;
@property (nonatomic, assign) int Aim3;
@property (nonatomic, assign) int Aim4;
@property (nonatomic, assign) int Testspeed;
@property (nonatomic, assign) int Testspeed2;
@property (nonatomic, assign) int AimR;
@property (nonatomic, assign) int isZoomm;
@end


NS_ASSUME_NONNULL_END
