#include "Color.h"
#pragma mark - 颜色定义
Color Color::Black = Color(0, 0, 0);
Color Color::White = Color(255, 255, 255);
Color Color::Red = Color(255, 0, 0);
Color Color::Green = Color(5, 232, 65);
Color Color::Blue = Color(0, 255, 255);
Color Color::Orange = Color(243, 158, 0);
Color Color::Yellow = Color(255, 255, 0);
Color Color::Gray = Color(128, 128, 128);
Color Color::Xue1 = Color(0,255,255);
Color Color::Xue2 = Color(250, 22, 0);//绿色
Color Color::Xue3 = Color(255, 165, 0);//
Color Color::Che = Color(0, 255, 0);//n绿色
Color Color::Guge = Color(241, 115, 172);
Color Color::Quan = Color(234, 102, 166);
Color Color::Wuqi = Color(64, 224, 208);
Color Color::Yao = Color(51, 163, 220);
Color Color::Zhen = Color(0, 255, 127);
Color Color::Dui = Color(124, 252, 0);
Color Color::Ji = Color(255, 0, 0);
Color Color::renji = Color(255, 165, 00);//绿色
Color Color::nee = Color(255, 0,255);
Color Color::Gttt = Color(237, 10,245);
Color Color::BuB = Color(122, 5,5);
Color Color::AAAbbb = Color(143, 5,173);
Color Color::pop = Color(139, 254,2);
Color Color::bbbb = Color(255, 102,102);
Color Color::sbs = Color(247, 5,5);
Color Color::rrtt = Color(150, 3,3);
Color Color::Gren = Color(13, 105, 65);
//box
Color Color::sky1 = Color(0,132,255,172);
Color Color::skyT = Color(0,95,183,172);
//box
Color Color::rdd = Color(255,0,0,145);
Color Color::rddt = Color(176,0,0,145);
//box
Color Color::bot1 = Color(198, 189, 189, 360);
Color Color::bott = Color(144, 144, 144, 360);
//box
Color Color::bubb = Color(11,0,255,145);
Color Color::bubbt = Color(8,0,187,145);


Color Color::yyy = Color(255,0,161,145);
Color Color::yyyt = Color(170,0,107,145);

Color Color::yyyw = Color(247,0,254,145);
Color Color::yyywt = Color(181,0,186,145);

Color Color::boy = Color(255,254,4,145);
Color Color::boyt = Color(170,170,0,145);

Color Color::hier = Color(65,237,0,145);
Color Color::hirt = Color(47,162,4,145);

Color Color::fuck = Color(4,7,162,145);
Color Color::fuckt = Color(2,5,121,145);
Color Color::Cleen = Color(255,255,255,0);
